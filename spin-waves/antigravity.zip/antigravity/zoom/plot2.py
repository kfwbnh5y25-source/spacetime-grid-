
import re
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.tri as mtri

from kNET import load_hdf


# ============================================================
# Configuration
# ============================================================

FILE = "data2.h5"
OUTPUT_DIR = Path("arnold_tongues2")

LABELS = ["half", "full","halfaverage"]

FREQ_MIN = 4050
FREQ_MAX = 4080

# Set this to the actual SA span used for each measurement.
SA_SPAN_MHZ = 5.0

EPS = 1e-30

CMAP = "viridis"
WIDTH_CMAP = "magma"
N_CMAP = "plasma"


# ============================================================
# Load HDF5
# ============================================================
pattern = re.compile(r"^(\d+)_(\d+)_(half|full|halfaverage)_")

data = load_hdf(FILE)
measurements = {}
from tqdm import tqdm
with data as d:
    keys=list(d.keys())
    for key in tqdm(keys):

        match = pattern.match((key))

        if match is None:
            continue

        a = float(match.group(1))
        f = float(match.group(2))
        label = match.group(3)

        """if a > 400:p
            continue"""

        if not FREQ_MIN <= f <= FREQ_MAX:
            continue
        if a<200:
            continue

        trace = np.asarray(d[key]["trace"])[:, 1].mean(axis=0)
        noise=trace.mean()/np.asarray(d[key]["trace"])[:, 1].mean(axis=-1).std()

        k = (label, a, f)

        if k in measurements:
            measurements[k][0] += trace
            measurements[k][1] += 1
        else:
            measurements[k] = [trace, 1]


# ============================================================
# Spectral metrics
# ============================================================
from  scipy.signal import savgol_filter
import matplotlib.pyplot as plt
def spectral_metrics(spectrum, frequency):
    """
    Returns:
        width: equivalent Gaussian FWHM (MHz), or 0 if no peak
        n_eff: effective number of occupied bins, or 0 if no peak
    """

    spectrum = np.asarray(spectrum, dtype=float)
    frequency = np.asarray(frequency, dtype=float)

    peak = np.max(spectrum)
    max_noise = np.max(spectrum[:50])
    mean_noise = np.mean(spectrum[:50])
    if np.mean(spectrum)/mean_noise<10:
        return np.nan,np.nan


    # Use only power above background
    weights = spectrum.copy()
    weights[490:510]=0
    if np.max(weights)<=2*max_noise:
        return 0,0
    total = weights.sum()

    if total <= EPS:

        return 0.0, 0.0

    mean_f = np.sum(weights * frequency) / total
    variance = np.sum(weights * (frequency - mean_f)**2) / total

    width = 2.35482 * np.sqrt(variance)

    n_eff = total**2 / np.sum(weights**2)

    return width, n_eff
# Finalize averages
for k, (spectrum_sum, count) in measurements.items():
    measurements[k] = spectrum_sum / count
# ============================================================
# Plot helper
# ============================================================

def save_colormap(freq, amp, values, filename, title, cbar_label, cmap):
    valid = (
        np.isfinite(freq)
        & np.isfinite(amp)
        & np.isfinite(values)
    )

    freq = freq[valid]
    amp = amp[valid]
    values = values[valid]

    if len(values) < 3:
        print(f"Not enough valid points for {filename}")
        return

    # Remove duplicate coordinates
    coords = np.column_stack((freq, amp))
    _, unique_idx = np.unique(coords, axis=0, return_index=True)
    unique_idx = np.sort(unique_idx)

    freq = freq[unique_idx]
    amp = amp[unique_idx]
    values = values[unique_idx]

    triang = mtri.Triangulation(freq, amp)

    fig, ax = plt.subplots(figsize=(10, 7))

    contour = ax.tricontourf(
        triang,
        values,
        levels=40,
        cmap=cmap,
    )

    cbar = fig.colorbar(contour, ax=ax)
    cbar.set_label(cbar_label, fontsize=12)

    ax.set_xlabel("Frequency (MHz)", fontsize=13)
    ax.set_ylabel("Amplitude (mV)", fontsize=13)
    ax.set_title(title, fontsize=14)
    ax.set_xlim(FREQ_MIN, FREQ_MAX)
    ax.tick_params(direction="in", top=True, right=True)

    fig.tight_layout()
    fig.savefig(OUTPUT_DIR / filename, dpi=300)
    plt.close(fig)


# ============================================================
# Generate maps
# ============================================================

OUTPUT_DIR.mkdir(exist_ok=True, parents=True)

for label in LABELS:

    freq_points = []
    amp_points = []
    signal_points = []
    width_points = []
    n_points = []

    for (lab, a, f), spectra in measurements.items():

        if lab != label:
            continue

        # Average repetitions in linear power
        spectrum = spectra

        # SA frequency axis: centered at f/2
        spectrum_freq = np.linspace(
            f / 2 - SA_SPAN_MHZ / 2,
            f / 2 + SA_SPAN_MHZ / 2,
            len(spectrum),
        )

        signal = np.trapz(spectrum)

        width, n_eff = spectral_metrics(
            spectrum,
            spectrum_freq,
        )

        freq_points.append(f)
        amp_points.append(a)
        signal_points.append(signal)
        width_points.append(width)
        n_points.append(n_eff)

    if not freq_points:
        print(f"No measurements found for {label}")
        continue

    freq = np.asarray(freq_points)
    amp = np.asarray(amp_points)
    signal = np.asarray(signal_points)
    width = np.asarray(width_points)
    n_eff = np.asarray(n_points)

    signal_db = 10 * np.log10(np.maximum(signal, 1e-6))

    # Integrated power map
    signal_plot = np.clip(
        signal_db,
       -60,
        np.inf,
    )

    save_colormap(
        freq, amp, signal_plot,
        f"arnold_tongue_{label}.png",
        f"Arnold tongue - {label}",
        "Integrated signal (dB)",
        CMAP,
    )
    mask=~np.isnan(n_eff)
    print(mask.sum()/len(n_eff))

    # Spectral width map
    save_colormap(
        freq[mask], amp[mask], width[mask],
        f"spectral_width_{label}.png",
        f"Spectral width - {label}",
        "Equivalent Gaussian FWHM (MHz)",
        WIDTH_CMAP,
    )
    n_eff=np.clip(n_eff,0,150)

    # Effective number of occupied bins map
    save_colormap(
        freq[mask], amp[mask], n_eff[mask],
        f"spectral_N_{label}.png",
        f"Spectral participation ratio - {label}",
        r"Effective number of bins $N_{\mathrm{eff}}$",
        N_CMAP,
    )

print("Finished plotting.")
