import time

import numpy as np

from kNET import kNETInterface
from scipy.stats import qmc
from tqdm import trange
np.set_printoptions(suppress=True)
from kNET import HDF5Buffer
from scipy.signal.windows import tukey
from concurrent.futures import ThreadPoolExecutor
from threading import Lock

knet = kNETInterface()

awg = knet.awg
awg.output_voltage = 1.0
awg.clear_data()
awg.send_waveform(np.zeros(64000),segment_id=2)
sa = knet.sa
sa.write(":FORM REAL,32")
awg.sampling_freq = 64e9
awg.abort_generation()
sa.points = 1001
sa.averageNumber = 1


_cached_bl, _cached_bl_time = None, None
_BASELINE_MAX_AGE = 90

ramp_up = tukey(128, 1)[:64]
ramp_down = np.flip(ramp_up)


_cached_bl = None
_cached_bl_time = None
_BASELINE_MAX_AGE = 90

_baseline_executor = ThreadPoolExecutor(
    max_workers=1,
    thread_name_prefix="SA-baseline"
)
_baseline_lock = Lock()


def get_baseline():
    global _cached_bl, _cached_bl_time

    with _baseline_lock:
        now = time.monotonic()

        if (
            _cached_bl is None
            or (now - _cached_bl_time) > _BASELINE_MAX_AGE
        ):
            t0 = time.perf_counter()

            bl = np.power(10.0, sa.trigAndWait() / 10)

            _cached_bl = sa.get_frequencies().copy(),bl.copy()
            _cached_bl_time = time.monotonic()



        return _cached_bl


def invalidate_baseline():
    global _cached_bl, _cached_bl_time

    with _baseline_lock:
        _cached_bl = None
        _cached_bl_time = None

hdf_buf = HDF5Buffer(
    "data2.h5",
    script_filename=__file__,
    settings=sa.get_settings(),
    append=True,
    buffer_size=100,
)
keys = list(hdf_buf.get_keys())




RUN_ID = time.strftime("%Y%m%d_%H%M%S")
t_ns = np.arange(64000) / 64


def measure(a, f, label=1, index=None, repeat=0,resend_wf=True):
    global _cached_bl
    a = np.round(a)
    f = np.round(f)

    # Unique key for every individual acquisition
    key = f"{int(a)}_{int(f)}_{label}_{RUN_ID}_{index}_{0}"


    # Start baseline acquisition in the background.
    baseline_future = _baseline_executor.submit(get_baseline)
    sa_freq, bl = baseline_future.result()
    if resend_wf:


        wf = a / 1000 * np.sin(2 * np.pi * f / 1000 * t_ns)
        awg.send_waveform(wf, segment_id=1)
        # Wait only if the baseline acquisition hasn't finished yet.

    else:
        sa_freq,bl=_cached_bl
    if label.endswith("average"):
        awg.start_sequence((1, 2), (50, 3))
    awg.start_generation()

    try:
        spec = np.power(10.0, sa.trigAndWait() / 10) - bl
    finally:
        awg.abort_generation()

    hdf_buf.append_data(key, sa_freq, spec)

    return spec, sa_freq



import matplotlib.pyplot as plt


def eval_point(
    a,
    f,
    label=1,
    index=None,
    min_repeats=5,
    max_repeats=10,
    target_snr=10.0,
    detection_t=7.0,
    early_stop_t=0.5,
):
    """
    Adaptive repeated measurement.

    Detection:
        t = mean / (std / sqrt(N))

    Repeatability:
        SNR = abs(mean) / std

    Stops:
        - After min_repeats if t <= early_stop_t
        - Once detection_t and target_snr are reached
        - At max_repeats otherwise
    """

    global _cached_bl

    signals = []
    spectra = []

    for rep in range(max_repeats):


        spec, freq = measure(
            a,
            f,
            label=label,
            index=index,
            repeat=0,
                resend_wf = (rep==0)
        )

        invalidate_baseline()
        if spec is None:
            return

        spectra.append(spec)

        signal = np.trapz(spec)

        signals.append(signal)

        n = len(signals)

        if n < min_repeats:
            continue

        mean = np.mean(signals)
        std = np.std(signals, ddof=1)

        if std > 0:
            snr = abs(mean) / std
            t_stat = mean / (std / np.sqrt(n))
        else:
            snr = np.inf if mean != 0 else 0.0
            t_stat = np.inf if mean > 0 else (
                -np.inf if mean < 0 else 0.0
            )

        # Clearly below detection: stop early
        if t_stat <= early_stop_t:
            break
        if mean<1e-8:
            break

        # Both detection and repeatability are sufficient
        if t_stat >= detection_t:
            break

    mean = np.mean(signals)
    std = np.std(signals, ddof=1)
    spectra=np.asarray(spectra)


    if std > 0:
        snr = abs(mean) / std
        t_stat = mean / (std / np.sqrt(len(signals)))
    else:
        snr = np.inf if mean != 0 else 0.0
        t_stat = np.inf if mean > 0 else (
            -np.inf if mean < 0 else 0.0
        )

    n = len(signals)

    return {
        "spectrum": np.mean(spectra, axis=0),
        "frequency": freq,
        "signal": mean,
        "std": std,
        "snr": snr,
        "t": t_stat,
        "n_measurements": n,
        "detected": mean>1e-8,
        "reliable": (
             t_stat >= target_snr
        ),
    }





def main():
    global _cached_bl

    _cached_bl = None


    a_min, a_max = 250,350
    f_min, f_max = 4045, 4085

    m = 14
    n_points = 2**m

    sampler = qmc.Sobol(d=2, scramble=True, seed=42)
    samples = sampler.random_base2(m=m)

    a = a_min + samples[:, 0] * (a_max - a_min)
    f = f_min + samples[:, 1] * (f_max - f_min)

    f = np.round(f)
    a = np.round(a)

    N_atonce = 1000
    valid_indices = np.flatnonzero(a >= 0)

    N_atonce = 4500

    # Apply the amplitude cutoff consistently to both sweeps
    valid_indices = np.flatnonzero((a >= 0)&(a <=4000))

    for batch_start in range(0, len(valid_indices), N_atonce):

        batch_indices = valid_indices[batch_start:batch_start + N_atonce]

        # --------------------------------------------------------
        # Sample mode: f/2
        # --------------------------------------------------------

        knet.switch_to_sample()

        sa.sweepTime = 1 / 4
        sa.spanFrequency = 5e6
        sa.resolutionBandwidthAutoState = False
        sa.resolutionBandwidth = 500e3
        sa.referenceLevel = -35.8
        sa.scaleDiv = 4
        sa.averageNumber = 3

        for j in trange(len(batch_indices)):

            i = batch_indices[j]
            invalidate_baseline()

            sa.centerFrequency = f[i] / 2 * 1e6

            result = eval_point(
                    a[i],
                    f[i],
                    label="halfaverage",
                    max_repeats=15,
                    min_repeats=3,
                    index=i,
                    target_snr=20,
                    detection_t=20,
                    early_stop_t=1
            )
            if result is not None:
                print(
                    f"a={a[i]:.0f}, f={f[i]:.0f} | "
                    f"SNR={result['snr']:.2f} | "
                    f"t={result['t']:.2f} | "
                    f"N={result['n_measurements']} | "
                    f"Detected={result['detected']}"
            )



        hdf_buf.flush_to_hdf5()

        # --------------------------------------------------------
        # Excitation mode: f
        # --------------------------------------------------------

        knet.switch_to_excitation()

        sa.spanFrequency = 10e6
        sa.sweepTime = 1 / 10
        sa.averageNumber = 1
        sa.referenceLevel = -20
        sa.scaleDiv = 10
        sa.resolutionBandwidth = 20e3

        for j in trange(len(batch_indices)):
            i = batch_indices[j]

            sa.centerFrequency = f[i] * 1e6
            invalidate_baseline()

            result = eval_point(
                    a[i],
                    f[i],
                    label="full",
                    index=i,
                    min_repeats=2
            )
            if result is not None:

                print(
                    f"a={a[i]:.0f}, f={f[i]:.0f} | "
                    f"SNR={result['snr']:.2f} | "
                    f"t={result['t']:.2f} | "
                    f"N={result['n_measurements']} | "
                    f"Detected={result['detected']}"
            )

        hdf_buf.flush_to_hdf5()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt as e:
        print(e)
        hdf_buf.flush_to_hdf5()
        exit()
